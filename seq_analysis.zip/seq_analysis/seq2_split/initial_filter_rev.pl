use warnings;

$scriptname="initial_filter_rev";
BEGIN { our $start_run = time(); }
open(LOG,">LOG_$scriptname");

#INPUT all the MID tags. Order in which MIDs are specified is not important.
my $indmat = join("|","CGTGAT","ACATCG","GCCTAA","TGGTCA","CACTGT","ATTGGC","GATCTG","TCAAGT","CTGATC","AAGCTA",
"GTAGCC","TACAAG","TTGACT","GGAACT","TGACAT","GGACGG","CTCTAC","GCGGAC","GGCTAC","CCGTCC","GTCCGC","GTGGCC","ACAGGT",
"ACCAGT","AGATAA","AGCATA","AGCCGC","AGGATT","CACTAG","CAGAGA","CATACG","CCACTG","CGACTT","CGAGGC","CTCGAG","GACATC",
"GACGCA","GCAATC","GCCTCG","GGTTCA","TAGCTG","TCAGTC","TGAAGT","TTCGTT","CGATGT","TGACCA","ACAGTG","GCCAAT","CAGATC",
"CTTGTA","AGTCAA","AGTTCC","ATGTCA","GTGAAA","ATCACG","TTAGGC","ACTTGA","TAGCTT","ACTGAT","ATTCCT","GTTTCG","GATCAG",
"GAGTGG","CGTACG","GCTATG","GAATTC","GAGATT","ATTACT","TAATGC","GTAGAG","GGTAGC","ATGAGC","CAAAAG","CAACTA","CACCGG",
"CACGAT","CACTCA","CATGGC","CATTTT","CCAACA","CGGAAT","CTATAC","CTCAGA","GACGAC","TAATCG","TCCCGA"); 

#INPUT all the primer sequences. Order in which primers are specified is not important. Normally 2 primer sequences are present: forward and reverse.
my $primat = join("|","GTATGTCAAAAAGATCTGTGC","GGTGTAAACTTTAAACTGCAT","CATCATCATCATCATCATGAG","GCCAAGCTTGCATGCCTGCAG",
"GCTAGGGCCCAGGCGGCC","CCCTTGGCCGGCCTGGCC");

my($filehandle, $line, $file, $flag, $coord1, $coord2, $seqo, $seq, $score, $nnnlen, $gggstart, $ggglen, $xy, $no);
my $i=1;

#Names of input and output files
my @inpfiles = ("initial2b000","initial2b001","initial2b002","initial2b003");
open(OUT1,">2b000"); open(OUT2,">2b001"); open(OUT3,">2b002"); open(OUT4,">2b003"); 


open(UNCLASS,">noclass_seq");

foreach $file(@inpfiles)
{
	print "File: $file\t";

	open(IN,"<$file") or die "$file not found!\n";
	$flag=0; $coord1=''; $seqo=''; $seq=''; $coord2=''; $score=''; $nnnlen=''; $gggstart='';
	$filehandle=''; $ggglen=''; 

	while(<IN>)
	{
		$line=$_; 
		if($line =~ m/^\@M03419/ && $flag==0)	#INPUT sequencer name
		{
		$coord1 = $line; $flag=1; 
		next;
		}
		if($flag==1) 
		{
			$seqo = $line; $flag=2; 

			if ($seqo=~/^([A,T,G,C]{0,4})(${indmat})(G{0,3})(${primat})(.*)/)
			{
				$filehandle=join('','OUT',$i);
				$nnnlen=length($1); 
				$ggglen=length($3); 
				$gggstart=($-[3]);   
				$seq=$2.$4.$5; 

			}
			else{$filehandle="UNCLASS"; $seq=$seqo; $seq=~s/\n//;} 
		next;
		}
		
		if($line =~ m/^\+/ && $flag==2){$coord2 = $line; $flag=3; next;}
		if($flag==3)
		{
			$score = $line;

				if($filehandle=~/OUT/)
				{
				if($ggglen != 0){substr($score, $gggstart, $ggglen) = "";}
				substr($score, 0, $nnnlen) = ""; 
				}
				print $filehandle "$coord1$seq\n$coord2$score";
				$filehandle = '';
				$flag=0;
				next;
		}
	}
$i++;
print "Processing done\n";
}

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";












