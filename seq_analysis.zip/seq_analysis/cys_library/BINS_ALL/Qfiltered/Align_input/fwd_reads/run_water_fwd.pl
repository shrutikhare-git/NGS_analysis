#!/usr/bin/perl -w

BEGIN { our $start_run = time(); }
$scriptname="run_water_fwd.pl";
open(LOG,">LOG_$scriptname");

opendir( DIR,"seq_analysis/cys_library/BINS_ALL/Qfiltered/Align_input/fwd_reads/") || die print "Can't open directory.\n"; #INPUT path

@inpfiles = grep(/fasta/, readdir(DIR)); #grep input files

foreach $file(@inpfiles)
{
	print "File: $file\t";
	$inFile = $file;
	$file =~ s/\.fasta/\.out/; #changing file extesions for output files
	$outFile = $file;
	`water  -asequence wt_seq.fasta  -bsequence $inFile -outfile $outFile -gapopen 20.0 -gapextend 0.5 -awidth 150 -aformat srspair -auto`;
	#INPUT WT sequence file name

	print "Alignment done\n";
}

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";
