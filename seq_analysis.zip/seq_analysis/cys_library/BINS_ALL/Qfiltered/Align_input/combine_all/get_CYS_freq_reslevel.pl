use strict;
use warnings;

BEGIN { our $start_run = time(); }
my $scriptname="get_CYS_freq_reslevel";
open(LOG,">LOG_$scriptname");


open(IN,"<Freq_CYS_mutants.txt") or die "Freq_CYS_mutants.txt not found!\n"; #frequency file name
open(OUT,">Freq_CYS_mutants_res-level.txt"); #output file name
my $len=101; # INPUT length of the protein
my $mids=4; #INPUT number of MIDs





print OUT "Position\tWT_residue\tMutant_residue\tRead counts at MIDs(1 to $mids) --->\n";

my ($line,%hash,$key,%counts,$awt,$amut,$indices,$ky,$add,@arr1,@arr2,@arr3,@arr4,@arr5,@arr6,@add,$joinkey);
my $resno=0; my $i=0;
my @wtaa=("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y","*");
my @mutaa=("A","C","D","E","F","G","H","I","K","L","M","N","P","Q","R","S","T","V","W","Y","*");

while(<IN>)
{

$line=$_;
	if($line=~/(\d+)\t(\w)\t\w\w\w\t([\w\*])\t(.*)/)
		{
		$joinkey=join("\t",$1,$2,$3);
		$counts{"$joinkey"}++;
		push(@{$hash{$joinkey}},$4);
		}
}

my $hashkeyscount=keys %hash;

for($resno=0;$resno<=$len;$resno++)
{
	foreach $awt(@wtaa)
	{
		foreach $amut(@mutaa)
		{
		$ky=join("\t",$resno,$awt,$amut);
		if (exists $counts{$ky})
			{
			if($counts{"$ky"} > 1)
			{
			@add=(); @arr1=(); @arr2=(); @arr3=(); @arr4=(); @arr5=(); @arr6=();
			$indices=$counts{"$ky"};

			#max codons aa can have is 6.
			if($indices==2)
				{
					@arr1=split(/\t/,$hash{$ky}[0]);
					@arr2=split(/\t/,$hash{$ky}[1]);

					for($i=0;$i<$mids;$i++)
					{
						$add[$i]=$arr1[$i]+$arr2[$i];
					}

					print OUT "$ky";
					for($i=0;$i<$mids;$i++)
					{
						print OUT "\t$add[$i]";
					}
					print OUT "\n";
				}
			elsif($indices==3)
				{
					@arr1=split(/\t/,$hash{$ky}[0]);
					@arr2=split(/\t/,$hash{$ky}[1]);
					@arr3=split(/\t/,$hash{$ky}[2]);

					for($i=0;$i<$mids;$i++)
					{
						$add[$i]=$arr1[$i]+$arr2[$i]+$arr3[$i];
					}

					print OUT "$ky";
					for($i=0;$i<$mids;$i++)
					{
						print OUT "\t$add[$i]";
					}
					print OUT "\n";
					
				}
			elsif($indices==4)
				{

					@arr1=split(/\t/,$hash{$ky}[0]);
					@arr2=split(/\t/,$hash{$ky}[1]);
					@arr3=split(/\t/,$hash{$ky}[2]);
					@arr4=split(/\t/,$hash{$ky}[3]);

					for($i=0;$i<$mids;$i++)
					{
						$add[$i]=$arr1[$i]+$arr2[$i]+$arr3[$i]+$arr4[$i];
					}

					print OUT "$ky";
					for($i=0;$i<$mids;$i++)
					{
						print OUT "\t$add[$i]";
					}
					print OUT "\n";
				}
			elsif($indices==5)
				{
					@arr1=split(/\t/,$hash{$ky}[0]);
					@arr2=split(/\t/,$hash{$ky}[1]);
					@arr3=split(/\t/,$hash{$ky}[2]);
					@arr4=split(/\t/,$hash{$ky}[3]);
					@arr5=split(/\t/,$hash{$ky}[4]);

					for($i=0;$i<$mids;$i++)
					{
						$add[$i]=$arr1[$i]+$arr2[$i]+$arr3[$i]+$arr4[$i]+$arr5[$i];
					}

					print OUT "$ky";
					for($i=0;$i<$mids;$i++)
					{
						print OUT "\t$add[$i]";
					}
					print OUT "\n";
				}
			elsif($indices==6)
				{
					@arr1=split(/\t/,$hash{$ky}[0]);
					@arr2=split(/\t/,$hash{$ky}[1]);
					@arr3=split(/\t/,$hash{$ky}[2]);
					@arr4=split(/\t/,$hash{$ky}[3]);
					@arr5=split(/\t/,$hash{$ky}[4]);
					@arr6=split(/\t/,$hash{$ky}[5]);

					for($i=0;$i<$mids;$i++)
					{
						$add[$i]=$arr1[$i]+$arr2[$i]+$arr3[$i]+$arr4[$i]+$arr5[$i]+$arr6[$i];
					}

					print OUT "$ky";
					for($i=0;$i<$mids;$i++)
					{
						print OUT "\t$add[$i]";
					}
					print OUT "\n";
				}

			}
			else{print OUT "$ky\t@{$hash{$ky}}\tsingle\n";}
			}
		}
	}
}
print "Script ran successfully.\n";

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";

