use strict;
use warnings;
use List::MoreUtils qw(uniq);
use Data::Dumper qw(Dumper);

#if error 'can't locate moreutils', install using following command
#yum install perl-List-MoreUtils

open(IN,"<Table_sub.txt") or die "Table_sub.txt not found!\n"; #Substitution table file name
open(SINGLE,">single_muts.txt"); 
open(MULTI,">multi_muts.txt"); 
open(WT,">wt.txt");
open(SUMMARY,">summary_counts_classifyMuts.txt");

my($line,@arr,@arr1,@unq,$size,%wthash,$key);
my $single=0; my $dbl=0; my $trip=0; my $multi=0; my $wt=0; my $total=0; 

foreach $line(<IN>)
{
$total++;
@arr=(); @arr1=(); @unq=(); $size=();


@arr=split(/\t/,$line);		#array with all elements of line in Table_sub.txt

if($arr[4] eq "wt")		#if read is WT
{
$wt++;
$wthash{$arr[1]}++;		#number of WT reads at each MID
}
else				#if read is not WT then only 
{
@arr1=split(/\s/,$arr[5]);	#residue positions with substitutions 
@unq=uniq @arr1;		#unique residue positions with substitutions
$size=@unq;

if($size==1){$single++; print SINGLE "$line";}
if($size==2){$dbl++; print MULTI "$line";}
if($size==3){$trip++; print MULTI "$line";}
if($size>3){$multi++; print MULTI "$line";}
}

}

print WT "MID\tWT_seq_no.\n";
foreach $key(keys %wthash){print WT "$key\t$wthash{$key}\n";}

print SUMMARY "WT\tsingle\tdouble\ttriple\tmultiple\ttotal\n";
print SUMMARY "$wt\t$single\t$dbl\t$trip\t$multi\t$total\n";

print "Script ran successfully.\n";




