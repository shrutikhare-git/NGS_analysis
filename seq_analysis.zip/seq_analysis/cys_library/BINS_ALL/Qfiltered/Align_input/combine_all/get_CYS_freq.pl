use strict;
use warnings;

BEGIN { our $start_run = time(); }
my $scriptname="get_CYS_freq";
open(LOG,">LOG_$scriptname");

my $length=102; #INPUT amino acid sequence length
my $mids=4; #INPUT no. of MIDs
my $ntseq="ATGCAGTTTAAGGTTTACACCTATAAAAGAGAGAGCCGTTATCGTCTGTTTGTGGATGTACAGAGTGATATTATTGACACGCCGGGGCGACGGATGGTGATCCCCCTGGCCAGTGCACGTCTGCTGTCAGATAAAGTCTCCCGTGAACTTTACCCGGTGGTGCATATCGGGGATGAAAGCTGGCGCATGATGACCACCGATATGGCCAGTGTGCCGGTCTCCGTTATCGGGGAAGAAGTGGCTGATCTCAGCCACCGCGAAAATGACATCAAAAACGCCATTAACCTGATGTTCTGGGGAATATAA";
#INPUT nucleotide sequence








my($bin,$res,$mutcdn,$wtcdn,%hash,$ky,$key,$c1,$c2,$tp,%wthash,$mutcdno);
my $incmplt=0; my $cmplt=0;
my $i=1; my $j=1;

#Codons for CYS mutation
my @codons=('TGT','TGC');
my %codHash;

$codHash{'TTC'}='F';
$codHash{'TGC'}='C';
$codHash{'TAC'}='Y';
$codHash{'CAA'}='Q';
$codHash{'AAC'}='N';
$codHash{'CAC'}='H';
$codHash{'GAA'}='E';
$codHash{'GAC'}='D';
$codHash{'AAA'}='K';

$codHash{'ATC'}='I'; $codHash{'ATA'}='I'; 
$codHash{'TAA'}='*'; $codHash{'TGA'}='*'; 
$codHash{'GTC'}='V'; $codHash{'GTA'}='V'; 
$codHash{'GCC'}='A'; $codHash{'GCA'}='A'; 
$codHash{'GGC'}='G'; $codHash{'GGA'}='G'; 
$codHash{'CCC'}='P'; $codHash{'CCA'}='P'; 
$codHash{'ACC'}='T'; $codHash{'ACA'}='T'; 
$codHash{'CTC'}='L'; $codHash{'CTA'}='L'; $codHash{'TTA'}='L'; 
$codHash{'TCC'}='S'; $codHash{'TCA'}='S'; $codHash{'AGC'}='S';
$codHash{'CGC'}='R'; $codHash{'CGA'}='R'; $codHash{'AGA'}='R'; 

$codHash{'TTG'}='L';  $codHash{'CCG'}='P';  $codHash{'TGT'}='C';
$codHash{'AAG'}='K';  $codHash{'GGT'}='G';  $codHash{'TGG'}='W';
$codHash{'TAG'}='*';  $codHash{'CTG'}='L';  $codHash{'GAG'}='E';
$codHash{'ATT'}='I';  $codHash{'GGG'}='G';  $codHash{'CGG'}='R';
$codHash{'GCT'}='A';  $codHash{'CAG'}='Q';  $codHash{'TTT'}='F';
$codHash{'TCG'}='S';  $codHash{'GTT'}='V';  $codHash{'CGT'}='R';
$codHash{'GCG'}='A';  $codHash{'CCT'}='P';
$codHash{'GAT'}='D';  $codHash{'TCT'}='S'; 
$codHash{'ACG'}='T';  $codHash{'ACT'}='T';
$codHash{'GTG'}='V';  $codHash{'CAT'}='H';
$codHash{'AGG'}='R';  $codHash{'TAT'}='Y';
$codHash{'ATG'}='M';  $codHash{'CTT'}='L'; 
$codHash{'AGT'}='S';  $codHash{'AAT'}='N';


#### In case residue number absent from mutation table
my @ntseq=split("",$ntseq);
my %wtaahash;
my $no=0; my $wtresno=0;
for($no=0;$no<@ntseq-2;$no+=3)
{
$wtresno++;
$wtaahash{$wtresno}=$codHash{"$ntseq[$no]$ntseq[$no+1]$ntseq[$no+2]"};
}

open(IN,"<single_muts.txt") or die "single_muts.txt not found!\n"; #Name of the file containing single mutant information
open(OUT,">Freq_CYS_mutants.txt");
open(SUM,">summary_counts_Freq.txt");
print SUM "Incomplete codons\tComplete codons\n";

while(<IN>)
{
	if($_=~/\S+\t(\d+)\t\S+\t\d+\t\d+.*\t(\d+).*\t(\S+).*\t(\S+).*/)
	{
	$bin=$1; $res=$2; $wtcdn=$3; $mutcdno=$4; 

		if($mutcdno=~/(\w\w\w).*/) #will get rid of incomplete codons
		{
		$cmplt++;
		$mutcdn=$1;
		
		$ky=join("_",$res,$bin,$mutcdn); 
		$wthash{"$res"}=$codHash{$wtcdn}; #WT residue type assigned to res no.
		$hash{$ky}++; #calculating freq of mutant codons
		}
		else{$incmplt++;} #checks if codon is 3 bases, otherwise omitted.
	}


}
print SUM "$incmplt\t$cmplt\n";


for($i=1;$i<=$length;$i++)
{ 
	if(exists $wthash{$i})
	{
			foreach $c2(@codons) 
			{ 
				print OUT "$i\t$wthash{$i}\t$c2\t$codHash{$c2}";

					for($j=1;$j<=$mids;$j++)
					{
					$tp=join("_",$i,$j,$c2); 
					if(exists $hash{$tp}){print OUT "\t$hash{$tp}";}
					else{print OUT "\t0";}
					}
				print OUT "\n"; 				
			}
	}
	else
	{
			foreach $c2(@codons)
			{ 
				print OUT "$i\t$wtaahash{$i}\t$c2\t$codHash{$c2}";
	
					for($j=1;$j<=$mids;$j++)
					{
					$tp=join("_",$i,$j,$c2); 
					if(exists $hash{$tp}){print OUT "\t$hash{$tp}";}
					else{print OUT "\t0";}
					}
				print OUT "\n"; 
				
			}
		
	}
}
print "Script ran successfully.\n";

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";

