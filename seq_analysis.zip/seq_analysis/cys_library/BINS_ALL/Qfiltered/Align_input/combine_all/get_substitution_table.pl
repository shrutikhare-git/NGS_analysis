#!/usr/bin/perl -w


BEGIN { our $start_run = time(); }
$scriptname="get_substi_table";
open(LOG,">LOG_$scriptname");

open STAT,">","summary_counts_get_substi.txt";

print STAT "since while loop is used, indels and mutants will count all the indels/mutations (multiple per read).
and not the number of reads with indels/mutations.
In combine_all indels are removed at previous step so, indel numbers should be zero\n";
print STAT "Bin_No.\tWT\tMutants\tInDels\tNo. of reads\n";

my $pattern="ccdB_WT_seq"; #INPUT WT sequence header

opendir(DIR,"seq_analysis/cys_library/BINS_ALL/Qfiltered/Align_input/combine_all") || die print "Can't open directory.\n"; #INPUT path

@outfiles = grep(/\.combined_all/, readdir(DIR)); #grep input files

foreach $file(@outfiles)
{
	open IN,"<$file" or die "File not found!\n"; 
	print "File: $file\t";
	
	if($file =~ m/bin(\d+)\.combined_all/){$outfile = $1;} #changing file names for output files
	
	$flag=0; $mut=0; $indel=0; $wtreads=0; $readcount=0; @seqarr=''; @arr1=(); @arr2=(); $add=0; @seqarr=(); 

	foreach $line(<IN>)
	{
		$xycoord='';
		
		if($line =~ m/^$pattern/ && $flag == 0)
		{
			$seqarr[0] = $line; 
			$flag = 1; next;
		}
		if($flag==1)
		{
			$seqarr[1] = $line; 
			$flag = 2; next;
		}
		if($flag==2)
		{
			$seqarr[2] = $line;
			$seqarr[2] =~ m/^(\d+_\d+_\d+)/; 
			$xycoord = join("_",$1,$outfile); 

			$xybin{$xycoord}=$outfile; # which xy-coord belongs to which bin
			$flag = 3; 
		}
		
		if($flag==3)
		{
			$readcount++; 

			$seqarr[0] =~ m/$pattern\s+(\d+)\s(\S+)/; #captures WT sequence
			$add=($1-1); #this will make all numberings start from 0 as it does by default
			$seq = $2;

			$seqarr[0] = $seq;                                      # WT seq line
			$seqarr[1] = substr $seqarr[1], 50, length($seqarr[0]); # alignment match line
			$seqarr[2] = substr $seqarr[2], 50, length($seqarr[0]);	# query seq line	

			@arr1=split(//,$seqarr[0]); #WT seq array
			@arr2=split(//,$seqarr[2]); #mut seq array

			if($seqarr[1] !~ /\s/ && $seqarr[1] !~ /\./) # WT sequences with no deletions and substitutions
			{	
				$wtreads++;
				@{$posindel{$xycoord}}="wt"; 
				@{$possub{$xycoord}}="wt"; 
				$countindel{$xycoord}=0; 
				$countsub{$xycoord}=0; 

				#length of WT seq
				$lenwt=$add+length($seqarr[1]); #end pos of seq  
				$length{$xycoord}=join("_",$add+1,$lenwt);  #read numbering from add+1(1(for)/151(rev)) to length of read

				@{$noindel{$xycoord}}=""; @{$wtcodonindel{$xycoord}}=""; @{$mutcodonindel{$xycoord}}="";
				@{$nosub{$xycoord}}="";   @{$wtcodonsub{$xycoord}}="";   @{$mutcodonsub{$xycoord}}="";

				$flag=0; next;
			}
			else # If not WT then only check for deletions/substitutions
			{

			$len=$add+length($seqarr[1]); $length{$xycoord}=join("_",$add+1,$len); #read length of mutant reads

			while($seqarr[1] =~ m/(\s)/g) # Deletions. Substitutions could also be present here.
			{
				$indel++;
				$countindel{$xycoord}++;
				push(@{$posindel{$xycoord}},($-[1]+$add+1)); #position starting from 1

				if(($-[1]+$add)%3 == 0) #default numbering starts from 0
				{
					push(@{$noindel{$xycoord}},(int(($-[1]+$add)/3)+1)); #codon no. starting from 1
					push(@{$wtcodonindel{$xycoord}},$arr1[($-[1])].$arr1[($-[1])+1].$arr1[($-[1])+2]); #next 2 bases
					push(@{$mutcodonindel{$xycoord}},$arr2[($-[1])].$arr2[($-[1])+1].$arr2[($-[1])+2]); #next 2 bases
				}
				elsif(($-[1]+$add)%3 == 1)
				{ 
					push(@{$noindel{$xycoord}},(int(($-[1]+$add)/3)+1)); 
					push(@{$wtcodonindel{$xycoord}},$arr1[($-[1])-1].$arr1[($-[1])].$arr1[($-[1])+1]); #prevs and next bases
					push(@{$mutcodonindel{$xycoord}},$arr2[($-[1])-1].$arr2[($-[1])].$arr2[($-[1])+1]); #prevs and next bases
				}
				elsif(($-[1]+$add)%3 == 2)
				{
					push(@{$noindel{$xycoord}},(int(($-[1]+$add)/3)+1)); 
					push(@{$wtcodonindel{$xycoord}},$arr1[($-[1])-2].$arr1[($-[1])-1].$arr1[($-[1])]); #prevs 2 bases
					push(@{$mutcodonindel{$xycoord}},$arr2[($-[1])-2].$arr2[($-[1])-1].$arr2[($-[1])]); #prevs 2 bases
				} 
			
				$flag=0; next;
			}

			if($seqarr[1] !~ /\s/) #If there are no deletions anywhere in the entire seq then only check for substitutions
			{
			while($seqarr[1] =~ m/(\.)/g) 
			{
				$mut++;
				$countsub{$xycoord}++; 
				push(@{$possub{$xycoord}},($-[1]+$add+1)); #position starting from 1

				if(($-[1]+$add)%3 == 0) #default numbering starts from 0
				{
					push(@{$nosub{$xycoord}},(int(($-[1]+$add)/3)+1)); #codon no. starting from 1 
					push(@{$wtcodonsub{$xycoord}},$arr1[($-[1])].$arr1[($-[1])+1].$arr1[($-[1])+2]); #next 2 bases
					push(@{$mutcodonsub{$xycoord}},$arr2[($-[1])].$arr2[($-[1])+1].$arr2[($-[1])+2]); #next 2 bases
				}
				elsif(($-[1]+$add)%3 == 1)
				{ 
					push(@{$nosub{$xycoord}},(int(($-[1]+$add)/3)+1)); 
					push(@{$wtcodonsub{$xycoord}},$arr1[($-[1])-1].$arr1[($-[1])].$arr1[($-[1])+1]); #prevs and next bases
					push(@{$mutcodonsub{$xycoord}},$arr2[($-[1])-1].$arr2[($-[1])].$arr2[($-[1])+1]); #prevs and next bases
				}
				elsif(($-[1]+$add)%3 == 2)
				{
					push(@{$nosub{$xycoord}},(int(($-[1]+$add)/3)+1)); 
					push(@{$wtcodonsub{$xycoord}},$arr1[($-[1])-2].$arr1[($-[1])-1].$arr1[($-[1])]); #prevs 2 bases
					push(@{$mutcodonsub{$xycoord}},$arr2[($-[1])-2].$arr2[($-[1])-1].$arr2[($-[1])]); #prevs 2 bases
				} 

			}
			}
			}
			$flag = 0;
		}
		if($line !~ m/^$pattern/ && $flag==0){next;}
	}
	close IN;
	print STAT "$outfile\t$wtreads\t$mut\t$indel\t$readcount\n"; 
	print "Processing done\n";

}

open(OUT5,">Table_sub.txt");

foreach $key(sort keys %possub){print OUT5 "$key\t$xybin{$key}\t$length{$key}\t$countsub{$key}\t@{$possub{$key}}\t@{$nosub{$key}}\t@{$wtcodonsub{$key}}\t@{$mutcodonsub{$key}}\n";}

close STAT;

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";


