use strict;
use warnings;

my $pattern="ccdB_WT_seq"; #INPUT WT sequence header from wt_seq.fasta
my $mids=1; #INPUT no. of MIDs
my $end=306; #INPUT length of WT nucleotide sequence
my $wtseq="ATGCAGTTTAAGGTTTACACCTATAAAAGAGAGAGCCGTTATCGTCTGTTTGTGGATGTACAGAGTGATATTATTGACACGCCGGGGCGACGGATGGTGATCCCCCTGGCCAGTGCACGTCTGCTGTCAGATAAAGTCTCCCGTGAACTTTACCCGGTGGTGCATATCGGGGATGAAAGCTGGCGCATGATGACCACCGATATGGCCAGTGTGCCGGTCTCCGTTATCGGGGAAGAAGTGGCTGATCTCAGCCACCGCGAAAATGACATCAAAAACGCCATTAACCTGATGTTCTGGGGAATATAA";
#INPUT WT sequence









BEGIN { our $start_run = time(); }
my $scriptname="combine_all";
open(LOG,">LOG_$scriptname");

my ($m, $f, $r, @fwdfile, @revfile, %fwdhash, %revhash, $start1, $seq1, $end1, $readseq1, $posread1, $aln1, $m1, $m2);
my($key, $start2, $seq2, $end2, $readseq2, $posread2, $aln2, $alnfill, $fillcount,$poswt, $print3, $readid1, $readid2); 
my ($overlap, %olap, $subf, $subr, $readnew, $alnnew, $wtnew, $wtcomb, $posread, $strend, $alncomb, $readcomb, $var1, $var2); 

my $subset=0; my $short=0; my $withoverlap=0; my $sameolap=0; my $diffolap=0; my $withpart=0;
my $fwdnopart=0; my $revnopart=0; my $completefwd=0; my $completerev=0; my $i=0; my $noolap=0;
my $fwdindel=0; my $revindel=0; my $fwdnopartall=0; my $revnopartall=0;

my $print1=sprintf("%-46s",$pattern); 
my $print2=sprintf("%-50s",'aln_line');
my $wtlen=length($wtseq);



open(SUBSET,">subset.txt"); 
open(DIFFOLAP,">diffolap.txt");
open(SHORT,">short_reads.txt");
open(COUNTS,">summary_counts_combine_all.txt");
open(TEST,">check_these_reads.txt");
open(DEL,">reads_indels.txt");

print SUBSET "bin_no.\tfwd_start\tfwd_end\trev_start\trev_end\n"; #rev read is subset of fwd read
print DIFFOLAP "bin_no.\txy_coord\toverlap_length\toverlap_region_fwd\toverlap_region_rev\n"; #reads differ in overlapping region
print SHORT "category\tbin_no.\tread_id\tfwd_start\tfwd_end\trev_start\trev_end\n"; #fwd/rev read doesn't start/end at pos 1/306(for CcdB).


for($m=1;$m<=$mids;$m++)
{
@fwdfile=(); @revfile=(); $m1=(); $m2=(); %fwdhash=(); %revhash=(); $readid1=(); $readid2=();

$m1=join('',$m,'a'); 
$m2=join('',$m,'b'); 

open(IN1,"<seq_analysis/cys_library/BINS_ALL/Qfiltered/Align_input/fwd_reads/fwd_watout_Q20/bin_$m1.Q20") or die "bin_$m1.Q20 not found!\n"; #INPUT path
open(IN2,"<seq_analysis/cys_library/BINS_ALL/Qfiltered/Align_input/rev_reads/rev_watout_Q20/bin_$m2.Q20") or die "bin_$m2.Q20 not found!\n"; #INPUT path


@fwdfile=<IN1>;
@revfile=<IN2>;

open(OUT,">bin$m.combined_all"); #output files


#making hash for each read
for($f=2;$f<@fwdfile;$f+=4)
{
	if($fwdfile[$f]=~/^(\d+_\d+_\d+)/)
	{
		$readid1=$1;
		${$fwdhash{$readid1}}[0]=$fwdfile[$f-2]; #WT sequence
		${$fwdhash{$readid1}}[1]=$fwdfile[$f-1]; #alignment line
		${$fwdhash{$readid1}}[2]=$fwdfile[$f]; #read sequence	

		$var1=$fwdfile[$f-1]; $var1=~s/\n//; substr($var1,0,50)=''; 
		if($var1=~/\s+/){${$fwdhash{$readid1}}[0]="del"; $fwdindel++;} #gets rid of reads with deletions

	}
}
	
for($r=2;$r<@revfile;$r+=4)
{
	if($revfile[$r]=~/^(\d+_\d+_\d+)/)
	{
		$readid2=$1;
		${$revhash{$readid2}}[0]=$revfile[$r-2]; #WT sequence
		${$revhash{$readid2}}[1]=$revfile[$r-1]; #alignment line
		${$revhash{$readid2}}[2]=$revfile[$r]; #read sequence

		$var2=$revfile[$r-1]; $var2=~s/\n//; substr($var2,0,50)=''; 
		if($var2=~/\s+/){${$revhash{$readid2}}[0]="del"; $revindel++;} #gets rid of reads with deletions
	}
}

#iterating over forward hash
foreach $key(keys %fwdhash)
{
if(${$fwdhash{$key}}[0]=~/del/){print DEL "fwd\t$m\t$key\n";}
else
{
$start1=(); $seq1=(); $end1=(); $readseq1=(); $posread1=(); $aln1=();
$start2=(); $seq2=(); $end2=(); $readseq2=(); $posread2=(); $aln2=();
$poswt=(); $posread=(); $overlap=(); $subf=(); $subr=();
$readnew=(); $alnnew=(); $wtnew=(); $readcomb=(); $wtcomb=(); $alncomb=();
$strend=(); $fillcount=(); $alnfill='';

$print3=sprintf("%-46s",$key); 


#calculate lengths
	${$fwdhash{$key}}[0] =~ m/^$pattern\s+(\d+)\s(\S+)/;	#captures WT sequence - fwd
	$start1=$1; 						#start position (WT position) of fwd seq
	$seq1 = $2;
	$end1=$start1+length($seq1)-1; 

	${$fwdhash{$key}}[2] =~ m/^$key\s+(\d+)\s(\S+)/;	#captures read sequence - fwd
	$readseq1=$2;
	$posread1=$1;						#captures start position of forward read
	
	${$fwdhash{$key}}[1] =~ m/^aln_line\s+(.*)/;		#captures alignment line - fwd
	$aln1=$1;	
	
if(exists $revhash{$key})	#if fwd read doesn't have deletions then only check for reverse read
{
if(${$revhash{$key}}[0]=~/del/){print DEL "rev\t$m\t$key\n";}
else
{
$withpart++;

	$poswt=sprintf("%3s",$start1);
	$posread=sprintf("%3s",$posread1);


	${$revhash{$key}}[0] =~ m/^$pattern\s+(\d+)\s(\S+)/;	#captures WT sequence - rev
	$start2=$1;						#start position (WT position) of rev seq
	$seq2 = $2;
	$end2=$start2+length($seq2)-1; 

	${$revhash{$key}}[2] =~ m/^$key\s+(\d+)\s(\S+)/;	#captures read sequence - rev
	$readseq2=$2;
	$posread2=$1;						#captures start position of rev read

	${$revhash{$key}}[1] =~ m/^aln_line\s+(.*)/;		#captures alignment line - rev
	$aln2=$1;

#overlap

			if($start1==1 && $end2==$end)			#both fwd and reverse cover entire 300bp range
			{ 

				if($start2 <= $end1 && $end2 >= $end1)		#overlap
				{
				$withoverlap++;					#number of sequences with overlap
					$overlap=$end1-$start2+1;		#extent of overlap
					$olap{$overlap}++;			#overlap distribution
	
				#matching overlapping regions
					$subf=substr($readseq1,$start2-1,$overlap);
					$subr=substr($readseq2,0,$overlap);
	
				#removing overlapping part from reverse reads
						$readnew=$readseq2; substr($readnew,0,$overlap)='';
						$alnnew=$aln2;      substr($alnnew,0,$overlap)='';
						$wtnew=$seq2;       substr($wtnew,0,$overlap)='';	
	
				#combining fwd and rev parts
						$wtcomb=join("",$seq1,$wtnew);
						$alncomb=join("",$aln1,$alnnew);
						$readcomb=join("",$readseq1,$readnew);
	
					if($subf eq $subr)
					{
					$sameolap++;
					print OUT "$print1$poswt $wtcomb\n$print2$alncomb\n$print3$posread $readcomb\n\n"; 
					}
				#reads overlap but are not identical in overlapping regions
					else
					{
					$diffolap++; 
					print DIFFOLAP "$m\t$key\t$overlap\t$subf\t$subr\n"; 
					}
	
	
				}

	
#no overlap,  all reads will start from 1 here as we already have that if loop added above
				elsif($start2 > $end1)
				{
					$noolap++;

					$strend=$wtlen-(length($seq1)+length($seq2));
					$fillcount=length(substr($wtseq,$end1,$strend));
					for($i=0;$i<$fillcount;$i++){$alnfill.="|";} 

					print OUT "$print1$poswt $seq1",substr($wtseq,$end1,$strend),"$seq2\n";
					print OUT "$print2$aln1$alnfill$aln2\n";
					print OUT "$print3$posread $readseq1",substr($wtseq,$end1,$strend),"$readseq2\n\n";
					
				}

				else{ print TEST "see these reads\n";}
			}
#subset	reads
			elsif($start2 <= $end1 && $end2 < $end1)	#reverse read is a subset of forward read
			{
				$subset++; print SUBSET "$m\t$key\t$start1\t$end1\t$start2\t$end2\n"; 
			}
			else{$short++; print SHORT "with_partner\t$m\t$key\t$start1\t$end1\t$start2\t$end2\n";}
}
}
else #forward read without partner, without deletions
{
$fwdnopartall++;

	if($start1 == 1 && $end1 == $end) #we have complete info about the reads so equivalent to overlapping read
	{
	$completefwd++; print OUT "${$fwdhash{$key}}[0]${$fwdhash{$key}}[1]${$fwdhash{$key}}[2]\n"; 
	}
	elsif($start1==1 && $end1 < $end)
	{
	$fwdnopart++;
	print OUT "${$fwdhash{$key}}[0]${$fwdhash{$key}}[1]${$fwdhash{$key}}[2]\n"; 
	}
	else{$short++; print SHORT "fwd_no_part\t$m\t$key\t$start1\t$end1\tNA\tNA\n";}
}

}
}
foreach $key (keys %revhash)
{
$start2=(); $seq2=(); $end2=();
if (exists $fwdhash{$key}){}
else
{ 
if(${$revhash{$key}}[0]=~/del/){print DEL "rev\t$m\t$key\n";}
else
{

$revnopartall++;



		${$revhash{$key}}[0] =~/^$pattern\s+(\d+)\s(\S+)/;	#captures WT sequence - rev
		$start2=$1;						#start position (WT position) of rev seq
		$seq2 = $2;
		$end2=$start2+length($seq2)-1; 

	if($end2 == $end && $start2==1) #we have complete info about the reads so equivalent to overlapping read
	{
		$completerev++; print OUT "${$revhash{$key}}[0]${$revhash{$key}}[1]${$revhash{$key}}[2]\n"; 
	}
	elsif($end2 == $end && $start2>1)
	{
	$revnopart++;
	print OUT "${$revhash{$key}}[0]${$revhash{$key}}[1]${$revhash{$key}}[2]\n"; 
	}
	else{$short++; print SHORT "rev_no_part\t$m\t$key\tNA\tNA\t$start2\t$end2\n";}




}
}
}
}	

#printing stats
print COUNTS "Short reads - reads not spanning the entire sequence length.
subset reads - reads where rev read ends before end of the fwd read.
Both these cases are excluded.\n\n";
print COUNTS "All counts are excluding deletions\n\nTotal reads\t",$withpart+$fwdnopartall+$revnopartall,"\n";
print COUNTS "Reads with partner\t$withpart
Reads with partner excluding short and subset reads\t",$withpart-($short+$subset),"\n";
print COUNTS "Overlapping reads\t$withoverlap
Non-overlapping reads\t$noolap
\tIdentical in overlapping region\t$sameolap
\tDifferent in overlapping region\t$diffolap
Only fwd present but, it spans full length\t$completefwd
Only rev present but, it spans full length\t$completerev

Rev read subset\t$subset
Reads don't span entire length\t$short
Forward reads with indels\t$fwdindel
Reverse reads with indels\t$revindel

check_these_reads.txt file should be empty!\n";

print "Script ran successfully.\n";

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";

