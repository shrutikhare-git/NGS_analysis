use strict;
use warnings;

open (OUT,">import_bins.sh");

my $midsno = 4;			#INPUT no. of MIDs
my $primerno = 2;		#INPUT no. of primers


my $outs = $midsno*$primerno;	

my @alphabet=("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
my $path="seq_analysis/cys_library"; #INPUT path
my $i=1;
my $j=1;
my ($k);
my $old=0;

for($j=1;$j<=$midsno;$j++)
{
	for($k=0;$k<$primerno;$k++)
	{
	print OUT "cat $path/seq1_split/bin_$j$alphabet[$k] $path/seq2_split/bin_$j$alphabet[$k] \> bin_$j$alphabet[$k].txt\n";
	}
}
