cat /seq_analysis/cys_library/seq1_split/bin_1a /seq_analysis/cys_library/seq2_split/bin_1a > bin_1a.txt
cat /seq_analysis/cys_library/seq1_split/bin_1b /seq_analysis/cys_library/seq2_split/bin_1b > bin_1b.txt
cat /seq_analysis/cys_library/seq1_split/bin_2a /seq_analysis/cys_library/seq2_split/bin_2a > bin_2a.txt
cat /seq_analysis/cys_library/seq1_split/bin_2b /seq_analysis/cys_library/seq2_split/bin_2b > bin_2b.txt
cat /seq_analysis/cys_library/seq1_split/bin_3a /seq_analysis/cys_library/seq2_split/bin_3a > bin_3a.txt
cat /seq_analysis/cys_library/seq1_split/bin_3b /seq_analysis/cys_library/seq2_split/bin_3b > bin_3b.txt
cat /seq_analysis/cys_library/seq1_split/bin_4a /seq_analysis/cys_library/seq2_split/bin_4a > bin_4a.txt
cat /seq_analysis/cys_library/seq1_split/bin_4b /seq_analysis/cys_library/seq2_split/bin_4b > bin_4b.txt
