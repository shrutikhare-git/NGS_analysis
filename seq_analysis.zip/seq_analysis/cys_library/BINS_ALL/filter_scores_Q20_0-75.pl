#!/usr/bin/perl -w

$scriptname="filter_scores_Q20_0-75";
BEGIN { our $start_run = time(); }
open(LOG,">LOG_$scriptname");

$minreadlen=75; #read length cutoff

$totreads=0; $reads=0; $usedread=0; $shortreads=0; $totgood=0; $vgoodreads=0; $goodshortreads=0; 

opendir (DIR,"/seq_analysis/cys_library/BINS_ALL") || die print "Can't open directory.\n"; #INPUT path

@inpfiles = grep( /\.txt/,readdir(DIR) ); #grep input files
foreach $infile(@inpfiles)
{
 	$outfile = $infile; print "Input bin:$infile\n"; 
	$outfile =~ s/txt/Q20_0-75/; #changing file extesions for output files
	
	open OUT,">$outfile";
	
	open (IN,"<$infile") or die "$infile not found!\n";
	
	$flag=0;$coord1='';$seq=''; $seqo='';$seq1='';$coord2='';$score='';$subend=''; 
	while (<IN>)
	{
		$line = $_;
		
		if($flag==0 && $line =~ m/^\@M03419/){$coord1 = $line; $flag=1; next;} #INPUT sequencer name
		if($flag==1)
		{
			$seq1 = $line; 
			$flag=2;
			next;
		}
		if($flag==2 && $line =~ m/^\+/){$coord2 = $line; $flag=3; next;}
		if($flag==3)
		{
			$totreads++; 

			if($line=~/(\!|\"|\#|\$|\%|\&|\'|\(|\)|\*|\+|\,|\-|\.|\/|0|1|2|3|4)/)
			{
			$subend=$-[0]; 
			$reads++;

			$seqbb=substr($line,$subend+1); 
			if($seqbb=~/(\!|\"|\#|\$|\%|\&|\'|\(|\)|\*|\+|\,|\-|\.|\/|0|1|2|3|4)/)
			{
				$nxtbb = $-[0]; 
			}
			$hash{$nxtbb}++; 

				if($subend >= $minreadlen) 
					{
					$usedread++;
					$seq=substr($seq1,0,$subend); 
					$score=substr($line,0,$subend);
					print OUT "$coord1$seq\n$coord2$score\n";
					}
				else{$shortreads++;}
			}
			else 
			{
			$totgood++;
			$line=~ s/\n//; 

				if(length ($line) >= $minreadlen) 
					{
					print OUT "$coord1$seq1$coord2$line\n"; 
					$vgoodreads++;
					}
				else{$goodshortreads++;}
			} 

			$coord1='';$seq=''; $seqo=''; $seq1='';$coord2='';$score='';$subend='';$xy='';$flag=0; next;
		}
		else{$coord1='';$seq='';$seqo=''; $seq1='';$coord2='';$score='';$subend='';$xy='';$flag=0;next;}
	}
	print "$infile done\n";
	close IN;
	close OUT;
}

open(BB,">next_badbase_freq.txt");
print BB "Interval\tFrequency\n";
foreach $key (sort {$b<=>$a} keys %hash){print BB "$key\t$hash{$key}\n";}

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n\n\n";
print LOG "Total reads:\t\t\t$totreads\n";
print LOG "Reads with low quality bases:\t$reads\n  Used reads  (length > $minreadlen):\t$usedread\n  Short reads (length < $minreadlen):\t$shortreads\n";
print LOG "Very Good reads:\t\t$totgood\n  Used reads  (length > $minreadlen):\t$vgoodreads\n  Short reads (length < $minreadlen):\t$goodshortreads\n";
print LOG "\n\nPercentage of short reads:\t",sprintf("%.2f",(($shortreads*100)/$totreads)),"\nThese reads are lost due to length constraint.\n";
print LOG "Short reads from \'Very Good reads\' category are not counted here.\n";
print LOG "\nReads with low quality bases and v good reads together will constitute total reads.\n";
