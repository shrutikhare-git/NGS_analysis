#!/usr/bin/perl -w

BEGIN { our $start_run = time(); }
$scriptname="Convert2Fasta";
open(LOG,">LOG_$scriptname");

opendir( DIR,"/seq_analysis/cys_library/BINS_ALL/Q20_0-75" ) || die print "Can't open directory.\n"; #INPUT path

@inpfiles = grep( /(a)\.Q20_0-75/,readdir(DIR) ); #grep input files

foreach $file(@inpfiles)
{			
	open IN,"<$file"; print "$file\n";
	
	$file =~ s/Q20_0-75/Q20_0-75\.fasta/; #changing file extesions for output files
	open OUT,">$file";
	
	$flag=0;
	while (<IN>)
	{
		$line = $_;
		
		if($line =~ m/^\@M03419/ && $flag==0) #INPUT sequencer name
		{
			$line=~/^\@M03419:\d+:\S+:\d+:(\S+):(\S+):(\S+)\s\d+:N:\d+:\d+/; #INPUT sequencer name
			$xy=join("_",$1,$2,$3); 

			$flag=1; next;
		}
		if($flag==1)
		{
			$seq1=$line;
			$seq = substr ($seq1,6); #INPUT MID tag length
			$seq=~ s/\n//;
			print OUT ">$xy\n$seq\n"; 
			$flag=0;
		}
	}
	close OUT; close IN;
	print "$file done\n";
}



my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";
