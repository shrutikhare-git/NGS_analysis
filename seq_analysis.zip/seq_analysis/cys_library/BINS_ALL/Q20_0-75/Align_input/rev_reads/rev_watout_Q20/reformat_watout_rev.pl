#!/usr/bin/perl -w

BEGIN { our $start_run = time(); }
$scriptname="reformat_watout_rev";
open(LOG,">LOG_$scriptname");

opendir(DIR, "/seq_analysis/cys_library/BINS_ALL/Q20_0-75/Align_input/rev_reads/rev_watout_Q20") || die print "Can't open directory.\n"; #INPUT path

@outfiles = grep(/\.out/, readdir(DIR)); #grep input files

$noofseq=0;

foreach $file(@outfiles)
{
	open IN,"<$file";
	$file =~ s/\.out//; #changing file extesions for output files
	open OUT,">$file";
	$flag=0; $seqflag=0; $concatflag=0; $idflag=0;
	
	while (<IN>)
	{
		$line = $_;
		if($line =~ m/^#[\=,\-]/)
		{
			if($concatflag>1)
			{
				print OUT "$print1$poswt $wtseq\n$print2$alnseq\n$print3$posmut $mtseq\n\n";
				$noofseq++;
				$print1=''; $print2=''; $print3=''; $wtseq=''; $alnseq='';$mtseq=''; $xy=''; $poswt=''; $posmut='';
			}
			$seqflag=1; $concatflag=1; $idflag=0; next;
		}
		if($seqflag==1 && $flag==0 && $line=~/^#\s2\:\s(\d+_\d+_\d+)/)
		{
			$xy=$1; 
		}
		if($seqflag==1 && $flag==0 && $line =~ m/^ccdB_WT_seq/) #INPUT wt sequence header
		{
			$seqflag=2; 

			if($idflag==0)
				{
				$print1 = "ccdB_WT_seq"; #INPUT WT sequence header
				$print1=sprintf("%-46s",$print1);

				if($line=~/^ccdB_WT_seq\s+(\d+)/){$poswt=$1;} #INPUT WT sequence header
				$poswt=sprintf("%3s",$poswt);
				$idflag=1;
				}

			if($line =~ m/\w+\s+\d+\s(\S+)\s+\d+\n/){$wtseq .= $1;}
			$flag=1; next; 
		}
		if($seqflag==2 && $flag==1)
		{
			$seqflag=3;
			if($idflag==1)
				{
				$print2 = "aln_line";
				$print2=sprintf("%-50s",$print2);
				$idflag=2;
				}
			if($line =~ m/^\s{21}(.*)\n/){$alnseq .= $1;}
			$flag=2; next;
		}
		if($seqflag==3 && $flag==2 && $line =~ m/^\d+_\d+/) #INPUT check read identifier in alignment file matches this pattern
		{
			$seqflag=1; $concatflag++;
			if($idflag==2)
				{
				$print3 = $xy;
				$print3=sprintf("%-46s",$print3); 

				if($line=~/^\S+\s+(\d+)/){$posmut=$1;}
				$posmut=sprintf("%3s",$posmut);

				$idflag=3;
				}
			if($line =~ m/^\S+\s+\d+\s(\S+)\s+\d+\n/){$mtseq .= $1;}
			$flag=0; next;
		}		
	}
	close IN;
	close OUT;
	print "$file Reformatted\n";
}
print "Please check output files\n";

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";
print LOG "\nNo. of sequences: $noofseq\n";
