#!/usr/bin/perl -w

$scriptname="bin_all_rev";
BEGIN { our $start_run = time(); }
open(LOG,">LOG_$scriptname");

$cutoff =8; #INPUT It's no of MIDs * no of primers
$cutoff1=9; #INPUT $cutoff+1
`rm *~`;

#INPUT the MID sequences below in the array @ind
$ind[0] = GGCTAC; #mid1
$ind[1] = CCGTCC; #mid2
$ind[2] = GTCCGC; #mid3 
$ind[3] = GTGGCC; #mid4

#INPUT the primer sequences below in the array @pri
$pri[0] = GCTAGGGCCCAGGCGGCC;
$pri[1] = CCCTTGGCCGGCCTGGCC;

$i=1;
foreach $a(@ind){ foreach $b(@pri){ $binHash{$a.$b} = OUT."$i"; $i++; } }
$binHash{'error'} = OUT9; open OUT9,">>undef_bin.seq2"; #INPUT file handler with $cutoff1 as suffix

#INPUT file and filehandler names. No. of files = No. of MIDs * No. of primers
open OUT1,	">bin_1a";	open OUT2,	">bin_1b";	open OUT3,	">bin_2a";	
open OUT4,	">bin_2b";	open OUT5,	">bin_3a";	open OUT6,	">bin_3b";	
open OUT7,	">bin_4a";	open OUT8,	">bin_4b";

opendir (DIR,"/seq_analysis/seq2_split") || die print "Can't open directory.\n"; #INPUT path
@inpfiles = grep( /^2b0/,readdir(DIR) ); #grep input files
foreach $file(@inpfiles)
{
	open IN,"</seq_analysis/seq2_split/$file"; #INPUT path
	
	$flag=0; $coord1=''; $seq=''; $seq='', $coord2=''; $score=''; $filehandle = ''; $match=0; $ntmat=0;
	while (<IN>)
	{
		$line = $_;
		
		if($line =~ m/^\@M03419/ && $flag==0){$coord1 = $line; $flag=1; next;} #INPUT sequencer name
		if($flag==1)
		{
			$seq = $line; $flag=2;
			$index = substr $seq, 0, 6;	#INPUT MID tag length
			$primer = substr $seq, 6, 18;	#INPUT primer length
			$keyval = $index.$primer;
			map
			{
				if($_ eq $keyval){$match++;}
				else{$ntmat++;}
			}keys %binHash;
			if($match==1 && $ntmat==$cutoff){$filehandle = $binHash{$index.$primer};}
			if($match==0 && $ntmat==$cutoff1){$filehandle = $binHash{'error'};}
			$match=0;$ntmat=0; 
			next;
		}
		if($line =~ m/^\+/ && $flag==2){$coord2 = $line; $flag=3; next;}
		if($flag==3)
		{
			$score = $line;
			print $filehandle "$coord1$seq$coord2$score";
			$filehandle = '';
			$flag=0;
			next;
		}
	}
	print "$file done\n";
}

my $end_run = time();
my $run_time = $end_run - our $start_run;
$run_time = $run_time/60;
print LOG "Scriptname:$scriptname\tTime taken: $run_time mins\n";
