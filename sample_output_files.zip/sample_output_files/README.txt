Freq_CYS_mutants_res-level.txt		- File contaning raw read counts from the deep sequencing data
Normalized_deep_seq_data.xlsx		- File containing normalized deep sequencing data
					  
For details about normalization of the data refer to the Analysis_Workflow.docx file and Najar et al., 2017 (doi:10.1016/j.str.2016.12.016).